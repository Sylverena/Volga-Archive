<?php
// Delete a student from the database.
