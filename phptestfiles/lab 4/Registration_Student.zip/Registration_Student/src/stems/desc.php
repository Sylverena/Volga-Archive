<!--
This file has the HTML & PHP necessary to display the top navigation menu.
This file uses the getMenuStatus() function to show whether the menu item is
selected or not.

The two spans are the icon (which is a font defined in styles.css) and the
word associated with the menu item.

Todo 2: Make the spans clickable by adding anchors around the spans.
The anchors need to call the getMenuStatus() function to highlight the menu
item or not.  Also, the href needs to call index.php with the correct
"command".
 -->
<?php include_once 'src/functions/getMenuStatus.php'; ?>
<div class="desc">
    <ul class="topnav">
        <li>
                <span class="material-symbols-outlined">home</span><br>
                <span>Home</span>
        </li>
        <li>
                <span class="material-symbols-outlined">person</span><br>
                <span>Student</span>
        </li>
        <li>
                <span class="material-symbols-outlined">school</span><br>
                <span>Course</span>
        </li>
        <li>
                <span class="material-symbols-outlined">apartment</span><br>
                <span>Campus</span>
        </li>
        <li style="float: right">
                <span class="material-symbols-outlined">help_center</span><br>
                <span>About</span>
        </li>
    </ul>
</div>
