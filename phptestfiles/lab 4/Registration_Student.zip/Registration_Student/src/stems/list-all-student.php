<?php
// List all of the students in a nicely formatted table.
