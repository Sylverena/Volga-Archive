<!-- This is the site header -->

<header>
    <h1 style="display: inline" id="site-title"><?php echo $appName; ?></h1>
</header>
