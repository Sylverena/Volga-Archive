<?php
include_once 'config/config.php';

// Todo 7: implement this include

// Connect to the database using the info in config

// Check that the connection worked
