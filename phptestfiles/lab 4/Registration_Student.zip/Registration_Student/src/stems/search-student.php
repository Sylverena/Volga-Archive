<?php
// Search for a student in the database.