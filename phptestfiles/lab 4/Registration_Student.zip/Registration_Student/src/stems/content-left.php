<?php include_once 'src/functions/getPageName.php'; ?>
<div class="column left" id="left-column">
    <?php
    // Todo 4: Implement this logic.
    // If the page name is 'home', you should display
    // src/html/default-left-side.html.  Otherwise you should display whichever
    // left-side menu HTML page is necessary.  I.e., display the
    //src/html/student-left-side-menu.html if it is the 'student' page.
    ?>
</div>
