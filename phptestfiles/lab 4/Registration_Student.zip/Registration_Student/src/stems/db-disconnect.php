<?php
// Todo 8: implement this include

// Free result set

// Close the connection
