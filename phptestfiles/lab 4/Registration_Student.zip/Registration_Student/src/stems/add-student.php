<?php
// Add a new student to the database.