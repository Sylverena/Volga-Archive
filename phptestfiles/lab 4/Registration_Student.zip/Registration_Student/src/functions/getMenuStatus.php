<?php
// Todo 1: Write this function
/**
 * This function determines whether a menu item is active by checking the
 * parameter against the associated session variable.
 *
 * @param int $menuItem An integer number representing the menu item.
 * @return string 'class="active"' if the menu item corresponds to the session
 * variable; Empty string otherwise.
 */
function getMenuStatus ( int $menuItem ) : string
{
    // debug: var_dump($_SESSION['menuItemActive']);

    $retval = '';
    switch ( $menuItem )
    {
        case 1: // Home
            // Check the menuItemActive session variable...

        // Other cases do the same but for their corresponding menu item

        default:
            $retval = '';
    }
    return $retval;
}