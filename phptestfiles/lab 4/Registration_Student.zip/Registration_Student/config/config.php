<?php
$appName = 'Registration';
$appVersion = '1.0.0';
$releaseYear = '2023';
$originator = 'ThkSoftware, LLC.';

$host =
$dbHost = '';
$dbUsername = '';
$dbPassword = '';
$dbCurrentDatabase = '';