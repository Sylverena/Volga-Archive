<?php
$appName = 'The Cypher Site';
$appVersion = '3.0.0';
$releaseYear = '2023';
$originator = 'ThkSoftware, LLC.';
