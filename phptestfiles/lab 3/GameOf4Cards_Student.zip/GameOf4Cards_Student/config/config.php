<?php
$appName = 'Game of 4 Cards';
$appVersion = '1.0.0';
$releaseYear = '2023';
$originator = '[ Your company here ]';