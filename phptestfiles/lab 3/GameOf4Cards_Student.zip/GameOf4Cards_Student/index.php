<?php
/*
 * This is the "main driver" of the program. As in the previous lab, this
 * program is implemented as a self-loading web page. Rather than keeping
 * global variables, the program should simply use pre-existing "global"
 * variable, $_SESSION. This is how the state of the program is maintained
 * between page loads.
 *
 * The way it works is this:
 * (1) Start a session
 * (2) If the request method is GET, initialize the game: initGame().
 * (3) If the request method is POST, update the game's state: updateGame().
 *
 * That code should go here.
 */

// debug: var_dump($_SERVER['REQUEST_METHOD']);

?>

<!DOCTYPE html>
<html lang="en">

<?php include_once 'config/config.php' ?>

<?php include_once 'src/pages/head.php' ?>

<body>

  <?php include_once 'src/pages/header.php' ?>
  <?php include_once 'src/pages/desc.php'; ?>

  <div class="row">
    <?php include_once 'src/pages/content-left.php' ?>
    <?php include_once 'src/pages/content-right.php' ?>
  </div>

  <?php include_once 'src/pages/footer.php' ?>

</body>

</html>
