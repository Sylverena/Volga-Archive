<div class="desc">
    <p>This site implements the <?php echo $appName; ?> game.</p>
</div>
