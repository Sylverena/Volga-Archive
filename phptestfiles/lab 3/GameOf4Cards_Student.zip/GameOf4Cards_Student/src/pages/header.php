<!-- This is the site header -->

<header>
    <img style="display: inline" id="site-logo" src="assets/images/padlock-outline-48.png" alt="">
    <h1 style="display: inline" id="site-title"><?php echo $appName; ?></h1>
</header>
