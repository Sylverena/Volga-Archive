<!-- This is the site footer -->

<footer>
    <p><?php echo "$appName - $appVersion. &copy; $releaseYear, $originator " ?></p>
</footer>
