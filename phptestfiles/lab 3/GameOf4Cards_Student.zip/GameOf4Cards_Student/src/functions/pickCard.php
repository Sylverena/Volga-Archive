<?php
// Todo: Complete this function.
/**
 * pickCard - Pick/draw a card from the "deck"
 * This function uses rand() to randomly generate a card (1-52). Next, figure
 * out the rank and finally, figure out the suit. The key is to remember that
 * there are 13 cards of each suit!
 * @return string The picked card of the form "value of suit".
 */
