create
    definer = zapata@`%` procedure getBookInfo(IN isbnQuery char(16))
begin
    select tblbooks.*, compositeName, fullName, genreName
    from tblbooks
             join tblbooksauthorsxref t on tblbooks.isbn = t.isbn
             join tblauthors t2 on t2.authorId = t.authorId

             join tblbooksgenresxref t3 on tblbooks.isbn = t3.isbn
             join tblgenres t4 on t4.genreId = t3.genreId

             join tblbookspublishersxref t5 on tblbooks.isbn = t5.isbn
             join tblpublishers t6 on t6.publisherId = t5.publisherId

    where tblbooks.isbn = isbnQuery;
end;

